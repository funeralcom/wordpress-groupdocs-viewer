<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Group Docs Embedder</title>
	<script type="text/javascript" src="js/tiny_mce_popup.js"></script>
	<script type="text/javascript" src="js/grpdocs-dialog.js"></script>
	<script type="text/javascript" src="js/jquery-1.3.2.min.js"></script>    

    <style type="text/css">
	h2 {
		font-size: 12px;
		color: #000000;
		padding:10px 0;
	}
	.mceActionPanel {
		margin-top:20px;
	}
	.diy{
		margin:5px 5px -5px 10px;
	}
    </style>
    
</head>
<body>
<form onsubmit="GrpdocsInsertDialog.insert();return false;" action="#">
    <!--p>
    <input name="diy" type="checkbox" value="1" class="diy"/>
    I'll insert the shortcode myself
    </p-->
  <h2 class="gray">Group Docs Shortcode Options</h2></td>
  </tr>
  
  <fieldset>
  <legend class="gray dwl_gray">Required</legend>
  <table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td align="right" class="gray dwl_gray"><strong>Document Link</strong><br />from your groupdocs.com Document Viewer</td>
    <td valign="top"><input name="url" type="text" class="opt dwl" id="url" style="width:200px;" /><br/>
	<span id="uri-note"></span></td>
  </tr>  
  </table>
  </fieldset>

  <br/>
  <fieldset>
  <legend class="gray dwl_gray">Optional</legend>
  <table width="100%" border="0" cellspacing="0" cellpadding="5">
  <tr>
    <td align="right" class="gray dwl_gray"><strong>Height</strong></td>
    <td valign="top" style="width:200px;"><input name="height" type="text" class="opt dwl" id="height" size="6"  value="700" style="text-align:right" />px</td>
  </tr>
  <tr>
    <td align="right" class="gray dwl_gray"><strong>Width</strong></td>
    <td valign="top"><input name="width" type="text" class="opt dwl" id="width" size="6" style="text-align:right" value="600" />px</td>
  </tr>
   </table>
   </fieldset>
   
   <table width="100%" border="0" cellspacing="0" cellpadding="5">
    <tr>
    <td colspan="2">
    <br />
    Shortcode Preview
    <textarea name="shortcode" cols="72" rows="2" id="shortcode"></textarea>
    </td>
  </tr> 
    
</table>

	<div class="mceActionPanel">
		<div style="float: left">
			<input type="button" id="insert" name="insert" value="{#insert}" onclick="GrpdocsInsertDialog.insert();" />
		</div>

		<div style="float: right">
			<input type="button" id="cancel" name="cancel" value="{#cancel}" onclick="tinyMCEPopup.close();" />
		</div>
	</div>
</form>

</body>
</html>