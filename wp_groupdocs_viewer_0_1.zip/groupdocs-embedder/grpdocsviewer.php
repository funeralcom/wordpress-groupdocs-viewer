<?php

/*
Plugin Name: Group Docs Embedder
Plugin URI: http://www.groupdocs.com/
Description: Lets you embed Group Docs in a web page using the Group Docs Viewer (no Flash or PDF browser plug-ins required).
Author: Sergiy Osypov <Sergiy.Osypov@groupdocs.com>
Author URI: http://www.groupdocs.com/
Version: 1.0
License: GPLv2
*/

include_once('grpdocs-functions.php');


function grpdocs_getdocument($atts) {

	extract(shortcode_atts(array(
		'file' => '',
		'width' => '',
		'height' => '',
		'page' => 0,
		'version' => 1,
	), $atts));

	$width  = intval($width);
	$height = intval($height);


	$code = "<iframe src='https://apps.groupdocs.com/document-viewer/embed/{$guid}' frameborder='0' width='%W%' height='%H%'></iframe>";
	                                                                                                            
	$guid = grpdocs_getGuid($file);

	$download = "<p><a href='https://api.groupdocs.com/v2.0/shared/files/" . $guid . "'>Download</a></p>";


	$code = str_replace("%W%", $width, $code);
	$code = str_replace("%H%", $height, $code);
	$code = str_replace("%P%", $page, $code);
	$code = str_replace("%V%", $version, $code);
	$code = str_replace("%B%", $download, $code);

	return $code;

}

//activate shortcode
add_shortcode('grpdocsview', 'grpdocs_getdocument');


// editor integration

// add quicktag
add_action('admin_print_scripts', 'grpdocs_admin_print_scripts');

// add tinymce button
add_action('admin_init','grpdocs_mce_addbuttons');

