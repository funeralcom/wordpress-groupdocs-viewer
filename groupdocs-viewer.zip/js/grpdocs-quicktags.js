edButtons[edButtons.length] =
new edButton('ed_h1'
	,'Grpdocs'
	,'[grpdocsannotation file="'
	,'"]'
	,'1'
);